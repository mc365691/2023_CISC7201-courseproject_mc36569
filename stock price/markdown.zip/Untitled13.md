```python
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import yfinance as yf

```


```python
start ='2016-01-01'
end = '2022-12-31'
#apple company stock name
stock = 'AAPL'
#data can download from
data=yf.download(stock, start, end)
```

    [*********************100%%**********************]  1 of 1 completed
    


```python
data.reset_index(inplace=True)
```


```python
data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>level_0</th>
      <th>index</th>
      <th>Date</th>
      <th>Open</th>
      <th>High</th>
      <th>Low</th>
      <th>Close</th>
      <th>Adj Close</th>
      <th>Volume</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>2016-01-04</td>
      <td>25.652500</td>
      <td>26.342501</td>
      <td>25.500000</td>
      <td>26.337500</td>
      <td>23.977478</td>
      <td>270597600</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>1</td>
      <td>2016-01-05</td>
      <td>26.437500</td>
      <td>26.462500</td>
      <td>25.602501</td>
      <td>25.677500</td>
      <td>23.376617</td>
      <td>223164000</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2</td>
      <td>2</td>
      <td>2016-01-06</td>
      <td>25.139999</td>
      <td>25.592501</td>
      <td>24.967501</td>
      <td>25.174999</td>
      <td>22.919142</td>
      <td>273829600</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3</td>
      <td>3</td>
      <td>2016-01-07</td>
      <td>24.670000</td>
      <td>25.032499</td>
      <td>24.107500</td>
      <td>24.112499</td>
      <td>21.951847</td>
      <td>324377600</td>
    </tr>
    <tr>
      <th>4</th>
      <td>4</td>
      <td>4</td>
      <td>2016-01-08</td>
      <td>24.637501</td>
      <td>24.777500</td>
      <td>24.190001</td>
      <td>24.240000</td>
      <td>22.067923</td>
      <td>283192000</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1757</th>
      <td>1757</td>
      <td>1757</td>
      <td>2022-12-23</td>
      <td>130.919998</td>
      <td>132.419998</td>
      <td>129.639999</td>
      <td>131.860001</td>
      <td>131.127060</td>
      <td>63814900</td>
    </tr>
    <tr>
      <th>1758</th>
      <td>1758</td>
      <td>1758</td>
      <td>2022-12-27</td>
      <td>131.380005</td>
      <td>131.410004</td>
      <td>128.720001</td>
      <td>130.029999</td>
      <td>129.307236</td>
      <td>69007800</td>
    </tr>
    <tr>
      <th>1759</th>
      <td>1759</td>
      <td>1759</td>
      <td>2022-12-28</td>
      <td>129.669998</td>
      <td>131.029999</td>
      <td>125.870003</td>
      <td>126.040001</td>
      <td>125.339417</td>
      <td>85438400</td>
    </tr>
    <tr>
      <th>1760</th>
      <td>1760</td>
      <td>1760</td>
      <td>2022-12-29</td>
      <td>127.989998</td>
      <td>130.479996</td>
      <td>127.730003</td>
      <td>129.610001</td>
      <td>128.889572</td>
      <td>75703700</td>
    </tr>
    <tr>
      <th>1761</th>
      <td>1761</td>
      <td>1761</td>
      <td>2022-12-30</td>
      <td>128.410004</td>
      <td>129.949997</td>
      <td>127.430000</td>
      <td>129.929993</td>
      <td>129.207779</td>
      <td>77034200</td>
    </tr>
  </tbody>
</table>
<p>1762 rows × 9 columns</p>
</div>




```python
ma_100_days = data.Close.rolling(100).mean()
```


```python
plt.figure(figsize=(9,7))
plt.plot(ma_100_days, 'y')
plt.plot(data.Close, 'g')
plt.show()
```


    
![png](output_5_0.png)
    



```python

```
